define({
  "name": "餐厨API说明",
  "version": "0.0.1",
  "description": "对餐厨项目接口进行说明",
  "title": "餐厨API",
  "url": "http://127.0.0.1",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2021-04-05T08:00:41.132Z",
    "url": "https://apidocjs.com",
    "version": "0.27.1"
  }
});

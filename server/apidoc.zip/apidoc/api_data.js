define({ "api": [
  {
    "type": "post",
    "url": "/food/company",
    "title": "创建餐饮企业信息",
    "version": "0.0.1",
    "description": "<p>基础数据创建之生成餐饮企业信息的接口。</p>",
    "group": "Basic_data",
    "parameter": {
      "fields": {
        "入参": [
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "companyName",
            "description": "<p>餐饮企业名称</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "businessLicense",
            "description": "<p>营业执照</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "legalRepresentative",
            "description": "<p>法人代表</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "phone",
            "description": "<p>联系电话</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>地址</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "lngAndLat",
            "description": "<p>经纬度</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "level",
            "description": "<p>等级</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "adminCode",
            "description": "<p>行政区域编码</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "入参样例：",
          "content": "{\n    \"companyName\": \"好想来餐饮\",\n    \"businessLicense\": \"12435980622\",\n    \"legalRepresentative\": \"赵\",\n    \"phone\": \"18630992352\",\n    \"address\": \"广东省汕头市\",\n    \"lngAndLat\": \"(113.23, 23.16)\",\n    \"level\": \"第一等级\",\n    \"adminCode\": \"440101\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "出参": [
          {
            "group": "出参",
            "type": "int",
            "optional": false,
            "field": "Code",
            "description": "<p>接口返回编码：200-成功；2003-生成数据失败；</p>"
          },
          {
            "group": "出参",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>消息描述</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "返回成功样例：",
          "content": "{\n\t\"Code\": 200,\n\t\"Message\": \"成功\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "返回失败样例：",
          "content": "{\n\t\"Code\": 2003,\n\t\"Message\": \"生成数据失败\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "server/kitchen-provider/src/main/java/cn/guet/kitchen/controller/FoodCompanyController.java",
    "groupTitle": "Basic_data",
    "name": "PostFoodCompany"
  },
  {
    "type": "post",
    "url": "/maintenance/company",
    "title": "创建维保公司信息",
    "version": "0.0.1",
    "description": "<p>基础数据创建之生成维保公司信息的接口。</p>",
    "group": "Basic_data",
    "parameter": {
      "fields": {
        "入参": [
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "companyName",
            "description": "<p>公司名称</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "businessLicense",
            "description": "<p>营业执照</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "legalRepresentative",
            "description": "<p>法人代表</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "phone",
            "description": "<p>联系电话</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>地址</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "lngAndLat",
            "description": "<p>经纬度</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "level",
            "description": "<p>等级</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "adminCode",
            "description": "<p>行政区域编码</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "入参样例：",
          "content": "{\n    \"companyName\": \"你好公司\",\n    \"businessLicense\": \"124359806\",\n    \"legalRepresentative\": \"张三\",\n    \"phone\": \"18630992356\",\n    \"address\": \"广东省广州市\",\n    \"lngAndLat\": \"(113.23, 23.16)\",\n    \"level\": \"第一等级\",\n    \"adminCode\": \"440100\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "出参": [
          {
            "group": "出参",
            "type": "int",
            "optional": false,
            "field": "Code",
            "description": "<p>接口返回编码：200-成功；2003-生成数据失败；</p>"
          },
          {
            "group": "出参",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>消息描述</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "返回成功样例：",
          "content": "{\n\t\"Code\": \"200\",\n\t\"Message\": \"成功\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "返回失败样例：",
          "content": "{\n\t\"Code\": 2003,\n\t\"Message\": \"生成数据失败\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "server/kitchen-provider/src/main/java/cn/guet/kitchen/controller/MaintenanceCompanyController.java",
    "groupTitle": "Basic_data",
    "name": "PostMaintenanceCompany"
  },
  {
    "type": "post",
    "url": "/maintenance/staff",
    "title": "创建维保公司员工信息",
    "version": "0.0.1",
    "description": "<p>基础数据创建之生成维保公司员工信息的接口。</p>",
    "group": "Basic_data",
    "parameter": {
      "fields": {
        "入参": [
          {
            "group": "入参",
            "type": "int",
            "optional": false,
            "field": "id",
            "description": "<p>员工工号</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "name",
            "description": "<p>员工姓名</p>"
          },
          {
            "group": "入参",
            "type": "int",
            "optional": false,
            "field": "age",
            "description": "<p>年龄</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "sex",
            "description": "<p>性别</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "phone",
            "description": "<p>联系电话</p>"
          },
          {
            "group": "入参",
            "type": "int",
            "optional": false,
            "field": "companyId",
            "description": "<p>公司ID</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "cardNum",
            "description": "<p>身份证号</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "入参样例：",
          "content": "{\n    \"id\": 111101,\n    \"name\": \"你好公司员工1号\",\n    \"age\": \"30\",\n    \"sex\": \"男\",\n    \"phone\": \"15768042390\",\n    \"companyId\": 1,\n    \"cardNum\": \"410823198607126060\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "出参": [
          {
            "group": "出参",
            "type": "int",
            "optional": false,
            "field": "Code",
            "description": "<p>接口返回编码：200-成功；2003-生成数据失败；</p>"
          },
          {
            "group": "出参",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>消息描述</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "返回成功样例：",
          "content": "{\n\t\"Code\": 200,\n\t\"Message\": \"成功\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "返回失败样例：",
          "content": "{\n\t\"Code\": 2003,\n\t\"Message\": \"生成数据失败\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "server/kitchen-provider/src/main/java/cn/guet/kitchen/controller/MaintenanceStaffController.java",
    "groupTitle": "Basic_data",
    "name": "PostMaintenanceStaff"
  },
  {
    "type": "post",
    "url": "/operation/company",
    "title": "创建运维公司信息",
    "version": "0.0.1",
    "description": "<p>基础数据创建之生成运维公司信息的接口。</p>",
    "group": "Basic_data",
    "parameter": {
      "fields": {
        "入参": [
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "companyName",
            "description": "<p>公司名称</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "businessLicense",
            "description": "<p>营业执照</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "legalRepresentative",
            "description": "<p>法人代表</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "phone",
            "description": "<p>联系电话</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "address",
            "description": "<p>地址</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "lngAndLat",
            "description": "<p>经纬度</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "level",
            "description": "<p>等级</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "adminCode",
            "description": "<p>行政区域编码</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "入参样例：",
          "content": "{\n    \"companyName\": \"运维公司\",\n    \"businessLicense\": \"124359806\",\n    \"legalRepresentative\": \"周\",\n    \"phone\": \"18630992356\",\n    \"address\": \"广西桂林\",\n    \"lngAndLat\": \"(113.23, 23.16)\",\n    \"level\": \"第一等级\",\n    \"adminCode\": \"440100\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "出参": [
          {
            "group": "出参",
            "type": "int",
            "optional": false,
            "field": "Code",
            "description": "<p>接口返回编码：200-成功；2003-生成数据失败；</p>"
          },
          {
            "group": "出参",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>消息描述</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "返回成功样例：",
          "content": "{\n\t\"Code\": \"200\",\n\t\"Message\": \"成功\"\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "返回失败样例：",
          "content": "{\n\t\"Code\": 2003,\n\t\"Message\": \"生成数据失败\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "server/kitchen-provider/src/main/java/cn/guet/kitchen/controller/OperationCompanyController.java",
    "groupTitle": "Basic_data",
    "name": "PostOperationCompany"
  },
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "server/apidoc/main.js",
    "group": "C:\\Users\\Cyan\\Desktop\\server\\apidoc\\main.js",
    "groupTitle": "C:\\Users\\Cyan\\Desktop\\server\\apidoc\\main.js",
    "name": ""
  },
  {
    "type": "post",
    "url": "/add/order",
    "title": "新增/修改/删除订单",
    "version": "0.0.1",
    "description": "<p>本例为运维端管理系统的新增订单说明，修改订单类似。</p>",
    "group": "maintenance",
    "parameter": {
      "fields": {
        "入参": [
          {
            "group": "入参",
            "type": "int",
            "optional": false,
            "field": "orderType",
            "description": "<p>订单类型（1：设备清洗  2：设备维修  3：设备安装），必填</p>"
          },
          {
            "group": "入参",
            "type": "int",
            "optional": false,
            "field": "foodCompanyId",
            "description": "<p>餐饮企业ID，必填</p>"
          },
          {
            "group": "入参",
            "type": "double",
            "optional": false,
            "field": "money",
            "description": "<p>订单金额</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "time",
            "description": "<p>维保日期，必填</p>"
          },
          {
            "group": "入参",
            "type": "int",
            "optional": false,
            "field": "maintenanceTimeSeg",
            "description": "<p>维保时间段（1：09:00-10:30  2：10:30-12:00  3：14:00-15:30 4：15:30-17:00），必填</p>"
          },
          {
            "group": "入参",
            "type": "int",
            "optional": false,
            "field": "genType",
            "description": "<p>订单产生方式（1：运维  2：餐饮  3：系统），必填</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "remark",
            "description": "<p>备注</p>"
          },
          {
            "group": "入参",
            "type": "int",
            "optional": false,
            "field": "batch",
            "description": "<p>订单批次</p>"
          },
          {
            "group": "入参",
            "type": "set",
            "optional": false,
            "field": "devices",
            "description": "<p>设备关联，必填</p>"
          },
          {
            "group": "入参",
            "type": "array",
            "optional": false,
            "field": "normal",
            "description": "<p>正常设备（父级：devices）</p>"
          },
          {
            "group": "入参",
            "type": "array",
            "optional": false,
            "field": "earlyWarning",
            "description": "<p>预警设备（父级：devices）</p>"
          },
          {
            "group": "入参",
            "type": "array",
            "optional": false,
            "field": "alarm",
            "description": "<p>报警设备（父级：devices）</p>"
          },
          {
            "group": "入参",
            "type": "String",
            "optional": false,
            "field": "deviceId",
            "description": "<p>设备ID（父级：normal||earlyWarning||alarm）</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "入参样例：",
          "content": "{\n    \"orderTypeCode\": 1,\n    \"foodCompanyId\": 1001,\n    \"money\": 90.5,\n    \"time\": \"2021-04-19\",\n    \"maintenancePeriod\": 2,\n    \"genType\": 1,\n    \"remark\": \"电话联系\",\n    \"devices\":\n        {\n            \"normal\":\n                [\n                    {\n                        \"deviceId\": 123456\n                    },\n                    {\n                        \"deviceId\": 123457\n                    },\n                    {\n                        \"deviceId\": 123458\n                    }\n                ],\n            \"earlyWarning\":\n                [\n                    {\n                        \"deviceId\": 123459\n                    },\n                    {\n                        \"deviceId\": 123450\n                    }\n                ],\n            \"alarm\":\n                [\n                    {\n                        \"deviceId\": 123451\n                    }\n                ]\n        }\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "出参": [
          {
            "group": "出参",
            "type": "String",
            "optional": false,
            "field": "Code",
            "description": "<p>接口返回编码；200-创建订单成功；1201-请求条件中，缺少必填参数；2001-数据库执行有异常；</p>"
          },
          {
            "group": "出参",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>消息描述</p>"
          },
          {
            "group": "出参",
            "type": "int",
            "optional": false,
            "field": "maintenanceId",
            "description": "<p>订单序号</p>"
          },
          {
            "group": "出参",
            "type": "int",
            "optional": false,
            "field": "maintenanceCompanyId",
            "description": "<p>维保公司ID</p>"
          },
          {
            "group": "出参",
            "type": "int",
            "optional": false,
            "field": "processorId",
            "description": "<p>派单员工工号</p>"
          },
          {
            "group": "出参",
            "type": "String",
            "optional": false,
            "field": "orderNumber",
            "description": "<p>订单编号</p>"
          },
          {
            "group": "出参",
            "type": "String",
            "optional": false,
            "field": "flowNum",
            "description": "<p>订单流水号</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "返回成功样例：",
          "content": "{\n    \"data\": {\n        \"code\": 200,\n        \"message\": \"创建订单成功\",\n        \"data\": {\n            \"maintenanceId\": 51,\n            \"maintenanceCompanyId\": 1,\n            \"isDeleted\": null,\n            \"insertTime\": \"2021-04-02 22:34:14\",\n            \"updateTime\": null,\n            \"orderTypeCode\": 1,\n            \"foodCompanyId\": 1001,\n            \"processorId\": 111101,\n            \"money\": 90.5,\n            \"orderStatus\": 1,\n            \"genType\": 1,\n            \"batch\": 1,\n            \"time\": \"2021-04-19\",\n            \"maintenancePeriod\": 2,\n            \"remark\": null,\n            \"warnId\": null,\n            \"orderNumber\": \"161737405597651\",\n            \"flowNum\": \"11001211\",\n            \"devices\": {\n                \"normal\": [\n                    {\n                        \"deviceId\": 123456\n                    },\n                    {\n                        \"deviceId\": 123457\n                    },\n                    {\n                        \"deviceId\": 123458\n                    }\n                ],\n                \"earlyWarning\": [\n                    {\n                        \"deviceId\": 123459\n                    },\n                    {\n                        \"deviceId\": 123450\n                    }\n                ],\n                \"alarm\": [\n                    {\n                        \"deviceId\": 123451\n                    }\n                ]\n            },\n            \"deleted\": null\n        }\n    }\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "返回失败样例：",
          "content": "{\n    \"Code\": \"2001\",\n\t   \"Message\": \"数据库执行有异常\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "server/kitchen-provider/src/main/java/cn/guet/kitchen/controller/OrderController.java",
    "groupTitle": "maintenance",
    "name": "PostAddOrder"
  },
  {
    "type": "post",
    "url": "/delete/order",
    "title": "删除订单",
    "version": "0.0.1",
    "description": "<p>本例为运维端管理系统的订单删除说明。</p>",
    "group": "maintenance",
    "parameter": {
      "fields": {
        "入参": [
          {
            "group": "入参",
            "type": "int",
            "optional": false,
            "field": "orderNumber",
            "description": "<p>订单编号</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "入参样例：",
          "content": "{\n    \"operationType\": \"delete\",\n    \"orderNumber\": \"161752709559154\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "出参": [
          {
            "group": "出参",
            "type": "String",
            "optional": false,
            "field": "Code",
            "description": "<p>接口返回编码；200-订单删除成功；1201-请求条件中，缺少必填参数；2001-数据库执行有异常；</p>"
          },
          {
            "group": "出参",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>消息描述</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "返回成功样例：",
          "content": "{\n    \"data\": {\n        \"code\": 200,\n        \"message\": \"订单删除成功\"\n    }\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "返回失败样例：",
          "content": "{\n    \"Code\": \"2001\",\n\t   \"Message\": \"数据库执行有异常\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "server/kitchen-provider/src/main/java/cn/guet/kitchen/controller/OrderController.java",
    "groupTitle": "maintenance",
    "name": "PostDeleteOrder"
  },
  {
    "type": "post",
    "url": "/select/order",
    "title": "查询订单",
    "version": "0.0.1",
    "description": "<p>运维端管理系统的查询订单接口说明，以下参数无值时为null。</p>",
    "group": "maintenance",
    "parameter": {
      "fields": {
        "入参": [
          {
            "group": "入参",
            "type": "int",
            "optional": false,
            "field": "foodCompanyId",
            "description": "<p>搜索范围（（默认）当前餐饮企业：对应ID  所有餐饮企业：null）</p>"
          },
          {
            "group": "入参",
            "type": "int",
            "optional": false,
            "field": "orderStatus",
            "description": "<p>订单状态（1：已分配  2：已处理  3、待确认  4、已确认 ）</p>"
          },
          {
            "group": "入参",
            "type": "int",
            "optional": false,
            "field": "genType",
            "description": "<p>下单方式（1：餐饮企业下单  2：系统下单  3：运维人员下单）</p>"
          },
          {
            "group": "入参",
            "type": "int",
            "optional": false,
            "field": "orderTypeCode",
            "description": "<p>订单类型（1：设备清洗  2：设备维修  3：设备安装）</p>"
          },
          {
            "group": "入参",
            "type": "date",
            "optional": false,
            "field": "insertTimeStart",
            "description": "<p>起始下单时间</p>"
          },
          {
            "group": "入参",
            "type": "date",
            "optional": false,
            "field": "insertTimeEnd",
            "description": "<p>终止下单时间</p>"
          },
          {
            "group": "入参",
            "type": "int",
            "optional": false,
            "field": "pageNumber",
            "description": "<p>页号（默认为 1）</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "入参样例：",
          "content": "{\n    \"foodCompanyId\": 1001,\n    \"orderStatus\": 1,\n    \"genType\": 1,\n    \"orderTypeCode\": 1,\n    \"insertTimeStart\": \"2021-04-01 08:00:00\",\n    \"insertTimeEnd\": \"2021-04-04 18:00:00\",\n    \"pageNumber\": 1\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "fields": {
        "出参": [
          {
            "group": "出参",
            "type": "String",
            "optional": false,
            "field": "Code",
            "description": "<p>接口返回编码；200-订单删除成功；1201-请求条件中，缺少必填参数；2001-数据库执行有异常；</p>"
          },
          {
            "group": "出参",
            "type": "String",
            "optional": false,
            "field": "Message",
            "description": "<p>消息描述</p>"
          },
          {
            "group": "出参",
            "type": "int",
            "optional": false,
            "field": "numberOfPages",
            "description": "<p>页面数量</p>"
          },
          {
            "group": "出参",
            "type": "int",
            "optional": false,
            "field": "outSelectSerial",
            "description": "<p>序号</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "返回成功样例：",
          "content": "{\n    \"data\": {\n        \"code\": 200,\n        \"message\": \"查询成功\",\n        \"data\": {\n            \"numberOfPages\": 8\n            \"selectResult\": [\n                {\n                    \"outSelectSerial\": 1\n                    \"pageNumber\": 1,\n                    \"maintenanceId\": 51,\n                    \"maintenanceCompanyId\": 1,\n                    \"isDeleted\": null,\n                    \"insertTime\": \"2021-04-02 22:34:14\",\n                    \"updateTime\": null,\n                    \"orderTypeCode\": 1,\n                    \"foodCompanyId\": 1001,\n                    \"processorId\": 111101,\n                    \"money\": 90.5,\n                    \"orderStatus\": 1,\n                    \"genType\": 1,\n                    \"batch\": 1,\n                    \"time\": \"2021-04-19\",\n                    \"maintenancePeriod\": 2,\n                    \"remark\": null,\n                    \"warnId\": null,\n                    \"orderNumber\": \"161737405597651\",\n                    \"flowNum\": \"11001211\",\n                    \"devices\": {\n                        \"earlyWarning\": [\n                            {\n                                \"deviceId\": 123459\n                            },\n                            {\n                                \"deviceId\": 123450\n                            }\n                        ],\n                        \"alarm\": [\n                            {\n                                \"deviceId\": 123451\n                            }\n                        ]\n                    },\n                    \"deleted\": null\n                }\n            ]\n        }\n    }\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "返回失败样例：",
          "content": "{\n    \"Code\": \"2001\",\n\t   \"Message\": \"数据库执行有异常\"\n}",
          "type": "json"
        }
      ]
    },
    "filename": "server/kitchen-provider/src/main/java/cn/guet/kitchen/controller/OrderController.java",
    "groupTitle": "maintenance",
    "name": "PostSelectOrder"
  }
] });
